---
layout: doc
title: OnePlus Root Guide
description: "Root OnePlus phones running OxygenOS. Complete guide covering bootloader unlock, MSM tool usage and root methods for all models."
---

# OnePlus Rooting Guide

> 🚧 **Guide Under Construction**
>
> The OnePlus rooting guide is being created to provide detailed instructions for all OnePlus devices. Please check back soon for the complete tutorial.